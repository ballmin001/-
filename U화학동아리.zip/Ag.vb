﻿Public Class Ag
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        Me.Hide()
    End Sub

    Private Sub Ag_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
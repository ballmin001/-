﻿Public Class 기본창
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        참고문헌.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        화면1.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        제작자.Show()
    End Sub

    Private Sub 기본창_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
